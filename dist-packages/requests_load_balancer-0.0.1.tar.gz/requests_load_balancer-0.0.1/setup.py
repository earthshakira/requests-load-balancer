"""Setup configuration for requests-load-balancer."""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
